#!/usr/bin/env node
'use strict';
const fs = require('node:fs'), path = require('node:path'), crypto = require('node:crypto');
const root = __dirname, read = f => JSON.parse(fs.readFileSync(path.join(root,f)));
const protocol = read('protocol.json');
for (const [file, hash] of Object.entries(protocol.files)) if (crypto.createHash('sha256').update(fs.readFileSync(path.join(root,file))).digest('hex') !== hash) throw Error('Snapshot hash mismatch: '+file);
const queries = read('queries.json');
function tokenize(q) { return q.toLowerCase().split(/[^a-z0-9$%.+#-]+/).filter(t => t.length > 1); }
// Identical scoring rules to src/js/terminal.js:doSearch at the snapshot date.
function search(index,q) {
  const terms=tokenize(q), res=[];
  for (const e of index) {
    const t=e.t.toLowerCase(), x=e.x.toLowerCase(), p=e.p.toLowerCase(); let score=0;
    for (const term of terms) {
      const inT=t.indexOf(term)>=0, inP=p.indexOf(term)>=0;
      let c=0,i=x.indexOf(term); while(i>=0 && c<8) {c++;i=x.indexOf(term,i+term.length);}
      if(!inT&&!inP&&!c) {score=0;break;}
      score+=(inT?12:0)+(inP?3:0)+c;
    }
    if(score>0) res.push({e,score});
  }
  return res.sort((a,b)=>b.score-a.score);
}
const results={protocol:protocol.id, runtime:process.version, n:queries.length, editions:{}};
for (const edition of ['before','after']) {
  const index=read(edition+'-index.json');
  const rows=queries.map(q=>{
    const terms=tokenize(q.query), target=e=>e.u===q.page&&e.a===q.anchor;
    const aligned=index.filter(target).some(e=>terms.every(t=>e.x.toLowerCase().includes(t)));
    const ranked=search(index,q.query), pos=ranked.findIndex(r=>target(r.e)), rank=pos<0?null:pos+1;
    return {...q,aligned,rank,reciprocalRank:rank?1/rank:0,top5:ranked.slice(0,5).map(r=>({page:r.e.u,anchor:r.e.a,score:r.score}))};
  });
  results.editions[edition]={indexEntries:index.length,aligned:rows.filter(r=>r.aligned).length,hit1:rows.filter(r=>r.rank===1).length,hit5:rows.filter(r=>r.rank&&r.rank<=5).length,mrr:rows.reduce((s,r)=>s+r.reciprocalRank,0)/rows.length,alignedHit5:rows.filter(r=>r.aligned&&r.rank&&r.rank<=5).length,rows};
}
results.pairs=queries.map((q,i)=>({query:q.query,beforeAligned:results.editions.before.rows[i].aligned,afterAligned:results.editions.after.rows[i].aligned,beforeRank:results.editions.before.rows[i].rank,afterRank:results.editions.after.rows[i].rank}));
const output=process.argv[2]||path.join(root,'run-output'); fs.mkdirSync(output,{recursive:true});
fs.writeFileSync(path.join(output,'results.json'),JSON.stringify(results,null,2)+'\n');
console.log(JSON.stringify({n:results.n,before:{...results.editions.before,rows:undefined},after:{...results.editions.after,rows:undefined}},null,2));
